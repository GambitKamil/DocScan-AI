using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class FinalGameTools
{
    private const string FinalScene = "Assets/FinalGame_Integrated.unity";

    [MenuItem("The Last Gate/Validate Final Scene")]
    public static void ValidateFinalScene()
    {
        if (EditorApplication.isPlaying)
        {
            Debug.LogWarning("Run scene validation outside Play Mode.");
            return;
        }
        Scene scene = SceneManager.GetActiveScene();
        if (scene.path != FinalScene)
        {
            Debug.LogWarning("Open " + FinalScene + " first.");
            return;
        }
        int failures = 0;
        foreach (GameObject root in scene.GetRootGameObjects())
        {
            foreach (Transform child in root.GetComponentsInChildren<Transform>(true))
            {
                int missing = GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(child.gameObject);
                if (missing > 0)
                {
                    Debug.LogError("Missing script: " + child.name, child);
                    failures += missing;
                }
            }
            foreach (MonoBehaviour component in root.GetComponentsInChildren<MonoBehaviour>(true))
            {
                if (component == null) continue;
                string[] fields = null;
                if (component is CompanionCommand) fields = new[] { "companion", "dialogueUI", "hintText" };
                else if (component is CompanionAgent) fields = new[] { "target" };
                else if (component is SwitchController) fields = new[] { "bridgeController" };
                else if (component is BridgeController) fields = new[] { "bridgeVisual", "bridgeBlocker", "closedBarrierVisual" };
                else if (component is DialogueUI) fields = new[] { "dialoguePanel", "dialogueContentText", "playerInputField", "sendButton", "errorPanel", "errorMessageText", "errorDismissButton", "llmService", "gateController" };
                else if (component is FinalGamePresentation) fields = new[] { "canvas", "turkishFont", "player", "companion", "command", "bridge", "dialogue", "leverRenderer", "leverOff", "leverOn" };
                if (fields == null) continue;
                var serialized = new SerializedObject(component);
                foreach (string field in fields)
                {
                    SerializedProperty property = serialized.FindProperty(field);
                    if (property == null || property.objectReferenceValue == null)
                    {
                        Debug.LogError(component.GetType().Name + "." + field + " is not assigned.", component);
                        failures++;
                    }
                }
            }
        }
        if (failures == 0)
            Debug.Log("[The Last Gate] Scene reference validation passed. Next: Play Mode and Ollama smoke tests.");
        else
            Debug.LogError("[The Last Gate] Scene validation found " + failures + " missing references.");
    }

    [MenuItem("The Last Gate/Build Windows x64")]
    public static void BuildWindows()
    {
        if (EditorApplication.isPlaying)
        {
            Debug.LogWarning("Stop Play Mode before building.");
            return;
        }
        if (!BuildPipeline.IsBuildTargetSupported(BuildTargetGroup.Standalone, BuildTarget.StandaloneWindows64))
        {
            Debug.LogError("Install Windows Build Support for Unity 6000.3.27f1 through Unity Hub.");
            return;
        }
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        string destination = Path.GetFullPath("Builds/Windows/TheLastGate.exe");
        Directory.CreateDirectory(Path.GetDirectoryName(destination));
        BuildReport report = BuildPipeline.BuildPlayer(new BuildPlayerOptions
        {
            scenes = new[] { FinalScene },
            locationPathName = destination,
            target = BuildTarget.StandaloneWindows64,
            options = BuildOptions.None
        });
        if (report.summary.result == BuildResult.Succeeded)
            Debug.Log("Windows build saved to " + destination);
        else
            Debug.LogError("Windows build failed: " + report.summary.result);
    }
}
