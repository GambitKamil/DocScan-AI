using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Presentation only: never moves the agent or changes collision geometry.
[DefaultExecutionOrder(-100)]
public class FinalGamePresentation : MonoBehaviour
{
    [SerializeField] private Canvas canvas;
    [SerializeField] private Font turkishFont;
    [SerializeField] private PlayerController player;
    [SerializeField] private CompanionAgent companion;
    [SerializeField] private CompanionCommand command;
    [SerializeField] private BridgeController bridge;
    [SerializeField] private DialogueUI dialogue;
    [SerializeField] private SpriteRenderer leverRenderer;
    [SerializeField] private Sprite leverOff;
    [SerializeField] private Sprite leverOn;
    [SerializeField] private Sprite[] idleFrames;
    [SerializeField] private Sprite[] runFrames;

    private TMP_FontAsset runtimeFont;
    private TMP_Text objective;
    private TMP_Text controls;
    private TMP_Text stage;
    private GameObject controlPanel;
    private GameObject missionPanel;
    private GameObject chapterPanel;
    private GameObject victoryRoot, errorRoot, victoryVeil, errorVeil;
    private SpriteRenderer companionRenderer;
    private Rigidbody2D companionBody;
    private float animationTime;
    private readonly Color gold = new Color32(224, 184, 110, 255);
    private readonly Color cream = new Color32(236, 233, 215, 255);

    private void Awake()
    {
        if (canvas == null) return;
        if (turkishFont != null)
        {
            runtimeFont = TMP_FontAsset.CreateFontAsset(turkishFont);
            runtimeFont.atlasPopulationMode = AtlasPopulationMode.Dynamic;
            runtimeFont.isMultiAtlasTexturesEnabled = true;
            runtimeFont.TryAddCharacters("ÇçĞğİıÖöŞşÜü…' →");
            foreach (TMP_Text text in canvas.GetComponentsInChildren<TMP_Text>(true))
                text.font = runtimeFont;
        }
        RectTransform card = Panel("MissionCard", new Vector2(0, 1),
            new Vector2(24, -24), new Vector2(405, 104));
        missionPanel = card.gameObject;
        Accent(card, new Vector2(0, 0), new Vector2(4, 104), gold);
        Label(card, "SON KAPI", 16, gold,
            new Vector2(20, -12), new Vector2(350, 22));
        objective = Label(card, "", 21, cream,
            new Vector2(20, -40), new Vector2(370, 50));

        RectTransform chapter = Panel("ChapterCard", new Vector2(1, 1),
            new Vector2(-24, -24), new Vector2(230, 55));
        chapterPanel = chapter.gameObject;
        stage = Label(chapter, "01 / ORMAN KARAKOLU", 15, gold,
            new Vector2(14, -16), new Vector2(204, 24));

        RectTransform footer = Panel("Controls", new Vector2(0.5f, 0),
            new Vector2(0, 14), new Vector2(600, 40));
        controlPanel = footer.gameObject;
        controls = Label(footer, "WASD  Hareket     C  Yoldaşa komut     E  Konuş", 17, cream,
            new Vector2(14, -9), new Vector2(572, 26));
        controls.alignment = TextAlignmentOptions.Center;
        ConfigureDialogueScroll();
        SetupModalPanels();
    }

    private void Start()
    {
        if (companion == null) return;
        companionRenderer = companion.GetComponent<SpriteRenderer>();
        companionBody = companion.GetComponent<Rigidbody2D>();
    }

    private void Update()
    {
        if (victoryVeil != null) victoryVeil.SetActive(victoryRoot != null && victoryRoot.activeSelf);
        if (errorVeil != null) errorVeil.SetActive(errorRoot != null && errorRoot.activeSelf);
        bool opened = bridge != null && bridge.IsActivated();
        if (leverRenderer != null)
        {
            leverRenderer.sprite = opened ? leverOn : leverOff;
            leverRenderer.color = opened ? new Color32(170, 241, 202, 255) : Color.white;
        }
        if (objective != null)
        {
            bool gateOpen = dialogue != null && dialogue.IsGateUnlocked;
            objective.text = !PlayerController.CanMove
                ? "Yolculuk tamamlandı."
                : gateOpen ? "Son Kapı'dan geç."
                : opened ? "Muhafızı bul. Geçiş izni iste."
                : command != null && command.HasCommandBeenSent
                    ? "Yoldaşın şaltere gidiyor…"
                    : "Yoldaşına yaklaş. C ile yardım iste.";
            stage.text = gateOpen ? "03 / SON KAPI" : opened ? "02 / KAPI MUHAFIZI" : "01 / ORMAN KARAKOLU";
        }
        if (missionPanel != null) missionPanel.SetActive(PlayerController.CanMove);
        if (chapterPanel != null) chapterPanel.SetActive(PlayerController.CanMove);
        bool inDialogue = dialogue != null && dialogue.IsDialogueOpen;
        if (controlPanel != null)
            controlPanel.SetActive(!inDialogue && PlayerController.CanMove);
        if (controls != null && player != null)
            controls.text = player.CanInteract
                ? "[E] Muhafızla konuş     WASD  Hareket"
                : "WASD  Hareket     C  Yoldaşa komut     E  Konuş";
        AnimateCompanion();
    }

    private void SetupModalPanels()
    {
        Transform victory = canvas.transform.Find("VictoryPanel");
        Transform error = canvas.transform.Find("ErrorPanel");
        if (victory != null)
        {
            victoryRoot = victory.gameObject;
            victoryVeil = ModalVeil(victory);
        }
        if (error != null)
        {
            errorRoot = error.gameObject;
            errorVeil = ModalVeil(error);
        }
        foreach (string name in new[] { "DialoguePanel", "VictoryPanel", "ErrorPanel" })
        {
            Transform panel = canvas.transform.Find(name);
            if (panel == null) continue;
            var line = new GameObject("GoldTrim", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
            line.layer = canvas.gameObject.layer;
            line.transform.SetParent(panel, false);
            var rect = line.GetComponent<RectTransform>();
            rect.anchorMin = new Vector2(0, 1);
            rect.anchorMax = Vector2.one;
            rect.pivot = new Vector2(0.5f, 1);
            rect.anchoredPosition = Vector2.zero;
            rect.sizeDelta = new Vector2(0, 3);
            line.GetComponent<Image>().color = gold;
            line.GetComponent<Image>().raycastTarget = false;
        }
    }

    private GameObject ModalVeil(Transform panel)
    {
        var obj = new GameObject(panel.name + "Backdrop", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        obj.layer = canvas.gameObject.layer;
        obj.transform.SetParent(canvas.transform, false);
        obj.transform.SetSiblingIndex(panel.GetSiblingIndex());
        var rect = obj.GetComponent<RectTransform>();
        rect.anchorMin = Vector2.zero;
        rect.anchorMax = Vector2.one;
        rect.offsetMin = rect.offsetMax = Vector2.zero;
        obj.GetComponent<Image>().color = new Color(0.015f, 0.025f, 0.035f, 0.72f);
        obj.SetActive(false);
        return obj;
    }

    private void ConfigureDialogueScroll()
    {
        Transform panel = canvas.transform.Find("DialoguePanel");
        if (panel == null) return;
        Transform body = panel.Find("DialogueContentText");
        if (body == null) return;
        var viewportObject = new GameObject("ReplyViewport", typeof(RectTransform),
            typeof(CanvasRenderer), typeof(Image), typeof(RectMask2D), typeof(ScrollRect));
        viewportObject.layer = canvas.gameObject.layer;
        viewportObject.transform.SetParent(panel, false);
        var viewport = viewportObject.GetComponent<RectTransform>();
        viewport.anchorMin = Vector2.zero;
        viewport.anchorMax = Vector2.one;
        viewport.offsetMin = new Vector2(24, 94);
        viewport.offsetMax = new Vector2(-24, -65);
        viewportObject.GetComponent<Image>().color = new Color(0, 0, 0, 0.001f);
        var text = body.GetComponent<TextMeshProUGUI>();
        if (text == null) return;
        body.SetParent(viewport, false);
        RectTransform content = text.rectTransform;
        content.anchorMin = new Vector2(0, 1);
        content.anchorMax = Vector2.one;
        content.pivot = new Vector2(0.5f, 1);
        content.anchoredPosition = Vector2.zero;
        content.sizeDelta = new Vector2(-8, 0);
        text.overflowMode = TextOverflowModes.Overflow;
        text.raycastTarget = false;
        var fitter = body.gameObject.AddComponent<ContentSizeFitter>();
        fitter.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;
        fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
        var scroll = viewportObject.GetComponent<ScrollRect>();
        scroll.viewport = viewport;
        scroll.content = content;
        scroll.horizontal = false;
        scroll.vertical = true;
        scroll.movementType = ScrollRect.MovementType.Clamped;
        scroll.scrollSensitivity = 25;
        Label((RectTransform)panel, "Enter: Gönder  /  Esc: Kapat  /  Tekerlek: Kaydır", 14,
            new Color32(157, 178, 172, 255), new Vector2(360, -24), new Vector2(750, 24));
    }

    private void AnimateCompanion()
    {
        if (companionRenderer == null || companionBody == null) return;
        bool moving = companionBody.linearVelocity.sqrMagnitude > 0.02f;
        Sprite[] frames = moving ? runFrames : idleFrames;
        if (frames == null || frames.Length == 0) return;
        animationTime += Time.deltaTime * (moving ? 10f : 5f);
        companionRenderer.sprite = frames[(int)animationTime % frames.Length];
        if (Mathf.Abs(companionBody.linearVelocity.x) > 0.05f)
            companionRenderer.flipX = companionBody.linearVelocity.x < 0f;
    }

    private RectTransform Panel(string name, Vector2 anchor, Vector2 position, Vector2 size)
    {
        var obj = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        obj.layer = canvas.gameObject.layer;
        obj.transform.SetParent(canvas.transform, false);
        var rect = obj.GetComponent<RectTransform>();
        rect.anchorMin = rect.anchorMax = anchor;
        rect.pivot = anchor;
        rect.anchoredPosition = position;
        rect.sizeDelta = size;
        var image = obj.GetComponent<Image>();
        image.color = new Color32(13, 25, 30, 235);
        image.raycastTarget = false;
        var outline = obj.AddComponent<Outline>();
        outline.effectColor = new Color32(121, 135, 113, 90);
        outline.effectDistance = new Vector2(1, -1);
        return rect;
    }

    private TMP_Text Label(RectTransform parent, string value, float size, Color color,
        Vector2 position, Vector2 dimensions)
    {
        var obj = new GameObject("Label", typeof(RectTransform));
        obj.layer = canvas.gameObject.layer;
        obj.transform.SetParent(parent, false);
        var text = obj.AddComponent<TextMeshProUGUI>();
        var rect = text.rectTransform;
        rect.anchorMin = rect.anchorMax = new Vector2(0, 1);
        rect.pivot = new Vector2(0, 1);
        rect.anchoredPosition = position;
        rect.sizeDelta = dimensions;
        if (runtimeFont != null) text.font = runtimeFont;
        text.fontSize = size;
        text.color = color;
        text.text = value;
        text.raycastTarget = false;
        text.richText = false;
        return text;
    }

    private void Accent(RectTransform parent, Vector2 position, Vector2 size, Color color)
    {
        var obj = new GameObject("Accent", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        obj.layer = canvas.gameObject.layer;
        obj.transform.SetParent(parent, false);
        var rect = obj.GetComponent<RectTransform>();
        rect.anchorMin = rect.anchorMax = rect.pivot = Vector2.zero;
        rect.anchoredPosition = position;
        rect.sizeDelta = size;
        obj.GetComponent<Image>().color = color;
        obj.GetComponent<Image>().raycastTarget = false;
    }

    private void OnDestroy()
    {
        if (runtimeFont != null)
        {
            foreach (Texture2D atlas in runtimeFont.atlasTextures)
                if (atlas != null) Destroy(atlas);
            if (runtimeFont.material != null) Destroy(runtimeFont.material);
            Destroy(runtimeFont);
        }
    }
}
