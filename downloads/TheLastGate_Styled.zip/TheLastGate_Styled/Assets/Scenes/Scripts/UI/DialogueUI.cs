using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class DialogueUI : MonoBehaviour
{
    [Header("Panels")]
    [SerializeField] private GameObject dialoguePanel;
    [Header("Text & Input Fields")]
    [SerializeField] private TextMeshProUGUI dialogueContentText;
    [SerializeField] private TMP_InputField playerInputField;
    [SerializeField] private Button sendButton;
    [Header("Error Popup")]
    [SerializeField] private GameObject errorPanel;
    [SerializeField] private TextMeshProUGUI errorMessageText;
    [SerializeField] private Button errorDismissButton;
    [Header("Services")]
    [SerializeField] private OllamaService llmService;
    [Header("Environment")]
    [SerializeField] private GateController gateController;

    private ILLMService service;
    private bool isGateUnlocked;
    private bool isSending;
    public bool IsDialogueOpen => dialoguePanel != null && dialoguePanel.activeSelf;
    public bool IsSending => isSending;
    public bool IsGateUnlocked => isGateUnlocked;

    private void Start()
    {
        service = llmService;
        HideDialogue();
        if (errorPanel != null) errorPanel.SetActive(false);
        if (sendButton != null) sendButton.onClick.AddListener(OnSendClicked);
        if (errorDismissButton != null) errorDismissButton.onClick.AddListener(HideError);
        if (playerInputField != null) playerInputField.characterLimit = 600;
        SetMessage("Geçiş izni istemek için muhafıza bir mesaj yaz.");
    }

    private void Update()
    {
        if (!IsDialogueOpen) return;
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (errorPanel != null && errorPanel.activeSelf) HideError();
            else HideDialogue();
            return;
        }
        if (isGateUnlocked) return;
        if (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter))
            OnSendClicked();
    }

    public void ShowDialogue()
    {
        if (dialoguePanel == null) return;
        dialoguePanel.SetActive(true);
        if (playerInputField != null)
        {
            playerInputField.gameObject.SetActive(!isGateUnlocked);
            playerInputField.interactable = !isSending && !isGateUnlocked;
        }
        if (sendButton != null)
        {
            sendButton.gameObject.SetActive(!isGateUnlocked);
            sendButton.interactable = !isSending && !isGateUnlocked;
        }
        if (isGateUnlocked)
            SetMessage("Kapı zaten açık.\n\nDevam etmek için Esc tuşuna bas.");
        else if (!isSending) FocusInput();
    }

    public void HideDialogue()
    {
        if (dialoguePanel != null) dialoguePanel.SetActive(false);
        if (errorPanel != null) errorPanel.SetActive(false);
        if (playerInputField != null) playerInputField.DeactivateInputField();
    }

    public void ShowError(string friendlyMessage)
    {
        if (errorMessageText != null)
        {
            errorMessageText.richText = false;
            errorMessageText.text = friendlyMessage;
        }
        if (errorPanel != null) errorPanel.SetActive(true);
        else SetMessage(friendlyMessage);
    }

    public void HideError()
    {
        if (errorPanel != null) errorPanel.SetActive(false);
        if (!isSending) FocusInput();
    }

    private void FocusInput()
    {
        if (IsDialogueOpen && !isGateUnlocked && playerInputField != null)
            playerInputField.ActivateInputField();
    }

    private void SetMessage(string text)
    {
        if (dialogueContentText == null) return;
        // Model-generated text is dialogue, never TMP markup.
        dialogueContentText.richText = false;
        dialogueContentText.text = text;
        ScrollRect scroll = dialogueContentText.GetComponentInParent<ScrollRect>();
        if (scroll != null && IsDialogueOpen)
        {
            Canvas.ForceUpdateCanvases();
            scroll.verticalNormalizedPosition = 1f;
        }
    }

    private void OnSendClicked()
    {
        if (!IsDialogueOpen || isSending || isGateUnlocked ||
            (errorPanel != null && errorPanel.activeSelf) || playerInputField == null)
            return;
        string message = playerInputField.text.Trim();
        if (string.IsNullOrWhiteSpace(message)) return;
        if (service == null)
        {
            ShowError("Ollama hizmeti bağlı değil. Sahne bağlantısını kontrol edin.");
            return;
        }
        StartCoroutine(RequestReply(message));
    }

    private IEnumerator RequestReply(string message)
    {
        isSending = true;
        playerInputField.text = "";
        playerInputField.interactable = false;
        if (sendButton != null) sendButton.interactable = false;
        SetMessage("Kapı muhafızı düşünüyor…");
        Debug.Log("[DialogueUI] Sending message: " + message);
        try
        {
            yield return service.SendMessage(message,
                response =>
                {
                    if (response == null || string.IsNullOrWhiteSpace(response.reply) ||
                        (response.decision != "OPEN_GATE" && response.decision != "DENY" && response.decision != "CONTINUE"))
                    {
                        ShowError("Muhafızdan geçersiz bir yanıt alındı. Lütfen tekrar deneyin.");
                        return;
                    }
                    Debug.Log("[DialogueUI] Decision: " + response.decision);
                    SetMessage(response.reply);
                    if (response.decision != "OPEN_GATE") return;
                    if (gateController == null)
                    {
                        ShowError("Kapı bağlantısı eksik. Sahne ayarlarını kontrol edin.");
                        return;
                    }
                    gateController.OpenGate();
                    isGateUnlocked = true;
                    SetMessage(response.reply + "\n\nKapı açıldı. Devam etmek için Esc tuşuna bas.");
                    playerInputField.gameObject.SetActive(false);
                    if (sendButton != null) sendButton.gameObject.SetActive(false);
                },
                error =>
                {
                    Debug.LogWarning("[DialogueUI] " + error);
                    SetMessage("Bağlantı kesildi. Tekrar deneyebilirsin.");
                    ShowError(error);
                });
        }
        finally
        {
            isSending = false;
            if (playerInputField != null) playerInputField.interactable = !isGateUnlocked;
            if (sendButton != null) sendButton.interactable = !isGateUnlocked;
            if (errorPanel == null || !errorPanel.activeSelf) FocusInput();
        }
    }

    private void OnDestroy()
    {
        if (sendButton != null) sendButton.onClick.RemoveListener(OnSendClicked);
        if (errorDismissButton != null) errorDismissButton.onClick.RemoveListener(HideError);
    }
}
