using UnityEngine;

[RequireComponent(typeof(Camera))]
public class CameraFollow : MonoBehaviour
{
    [Header("Target to Follow")]
    [SerializeField] private Transform target;
    [Header("Follow Settings")]
    [Range(1f, 15f)]
    [SerializeField] private float smoothSpeed = 5f;
    [SerializeField] private Vector3 offset = new Vector3(0, 0, -10);
    [Header("Map Bounds")]
    [SerializeField] private bool clampToMap;
    [SerializeField] private Vector2 mapMin = new Vector2(-21, -11);
    [SerializeField] private Vector2 mapMax = new Vector2(11, 5.5f);
    private Camera view;

    private void Awake() { view = GetComponent<Camera>(); }
    private void Start()
    {
        if (target != null) transform.position = DesiredPosition();
    }
    private void LateUpdate()
    {
        if (target == null) return;
        transform.position = Vector3.Lerp(transform.position, DesiredPosition(),
            1f - Mathf.Exp(-smoothSpeed * Time.deltaTime));
    }
    private Vector3 DesiredPosition()
    {
        Vector3 position = target.position + offset;
        if (!clampToMap || view == null || !view.orthographic) return position;
        float halfHeight = view.orthographicSize;
        float halfWidth = halfHeight * view.aspect;
        position.x = mapMax.x - mapMin.x <= halfWidth * 2
            ? (mapMin.x + mapMax.x) * 0.5f
            : Mathf.Clamp(position.x, mapMin.x + halfWidth, mapMax.x - halfWidth);
        position.y = mapMax.y - mapMin.y <= halfHeight * 2
            ? (mapMin.y + mapMax.y) * 0.5f
            : Mathf.Clamp(position.y, mapMin.y + halfHeight, mapMax.y - halfHeight);
        return position;
    }
}
