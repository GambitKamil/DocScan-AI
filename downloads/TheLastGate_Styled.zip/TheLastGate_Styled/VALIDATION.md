# Проверки файлов

PASS: C# syntax parser — 21 files.
PASS: ONNX structural checker — V14.

PASS All local scene references resolve (375 serialized documents).
PASS All original scene Rigidbody2D and Collider2D documents are unchanged.
PASS Agent collider, position, target, policy model and inference settings preserved.
PASS Original companion, switch and bridge prefabs untouched.
PASS No duplicate asset GUIDs; 29 new sprite subassets resolve.
PASS All new asset references resolve (except the existing Unity package sprite material).
PASS Transform hierarchy is acyclic and parent/child references agree.
PASS All explicit GameObject/component ownership references agree.
PASS Package declarations, lockfile and Unity version pin unchanged.
PASS V14 model SHA256 unchanged: 1a81ad01201f34e3491d25697966b836a4b0d9b381e76e09790a7375df713b9a
PASS Presentation references resolve to expected player/companion/bridge/dialogue types.

Not run: Unity C# compilation, Unity asset import, Play Mode, local Ollama requests, Windows player build.
